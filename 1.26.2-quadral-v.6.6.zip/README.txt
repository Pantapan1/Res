------------------{ Quadral resourcepack by Ignaf }------------------

Quadral is officialy available on the Minecraft Marketplace. 

This texture pack is protected and licensed under international copyright law.


 Installation Instructions:

	1. Start Minecraft and select "Options" from the main menu.
	2. In the options menu, choose the subcategory "Resource Packs".
	3. Click on "Open pack folder" in the bottom left corner - Minecraft will then open the corresponding folder.
	4. Here, you can copy and paste resource packs that you have downloaded - and you will have added the resource pack to your game.

	In order for all features of this pack to work properly you need to install Optifine
	Downloads Optifine on: optifine.net

 Enjoy :)  




Copyright ©2019 - 2025 Aaron Willumat. All rights reserved.